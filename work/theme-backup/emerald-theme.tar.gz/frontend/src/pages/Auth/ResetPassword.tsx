import { useLanguage as useUiLanguage } from "../../contexts/LanguageContext";
import { tr, direction } from "../../i18n/runtime";
import { useState } from "react";
import {
  Link,
  useSearchParams,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import api from "../../services/api";
import { clearAuthSession } from "../../services/authService";
export default function ResetPassword() {
  useUiLanguage();
  const [params] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const resetToken =
    params.get("token") ||
    (
      location.state as {
        resetToken?: string;
      } | null
    )?.resetToken;
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [message, setMessage] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  return (
    <main
      dir={direction()}
      className="flex min-h-screen items-center justify-center bg-[#103B35] p-6"
    >
      <form
        className="w-full max-w-md space-y-5 rounded-3xl bg-white p-8 text-slate-900"
        onSubmit={async (e) => {
          e.preventDefault();
          if (password !== confirm) {
            setMessage(tr("Passwords do not match"));
            return;
          }
          if (new TextEncoder().encode(password).length > 72) {
            setMessage(tr("Password is too long. Use a shorter password."));
            return;
          }
          setBusy(true);
          try {
            await api.post("/api/auth/reset-password", {
              token: resetToken,
              new_password: password,
            });
            setDone(true);
            setPassword("");
            setConfirm("");
            setMessage(
              tr(
                "Password updated and previous sessions revoked. Sign in with your new password.",
              ),
            );
            clearAuthSession();
            window.dispatchEvent(new Event("wameed:auth-invalid"));
            navigate("/reset-password", { replace: true, state: null });
          } catch {
            setMessage(
              tr(
                "The link is invalid or expired, or the new password does not meet the requirements.",
              ),
            );
          } finally {
            setBusy(false);
          }
        }}
      >
        <header>
          <p className="text-sm font-bold text-[#103B35]">
            {tr("\u0648\u064E\u0645\u0650\u064A\u0636")}
          </p>
          <h1 className="mt-2 text-2xl font-bold">
            {tr("Set a new password")}
          </h1>
        </header>
        {message && (
          <p role="status" className="rounded-xl bg-emerald-50 p-3 text-sm">
            {tr(message)}
          </p>
        )}
        {!done && !resetToken ? (
          <p className="text-sm text-amber-900">
            {" "}
            {tr(
              "Open your email recovery link or verify your phone recovery code first.",
            )}{" "}
            <Link className="underline" to="/forgot-password">
              {" "}
              {tr("New recovery request")}{" "}
            </Link>
          </p>
        ) : (
          !done && (
            <>
              <label className="block">
                {" "}
                {tr("New password")}{" "}
                <span className="relative mt-2 block">
                  <input
                    required
                    minLength={10}
                    maxLength={72}
                    type={show ? "text" : "password"}
                    autoComplete="new-password"
                    className="w-full rounded-xl border p-3 pe-12"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    aria-label={
                      show ? tr("Hide password") : tr("Show password")
                    }
                    className="absolute end-3 top-3"
                    onClick={() => setShow(!show)}
                  >
                    {show ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </span>
              </label>
              <p className="text-xs text-slate-600">
                {" "}
                {tr("Use at least 10 characters.")}{" "}
              </p>
              <label className="block">
                {" "}
                {tr("Confirm password")}{" "}
                <input
                  required
                  minLength={10}
                  type={show ? "text" : "password"}
                  autoComplete="new-password"
                  className="mt-2 w-full rounded-xl border p-3"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />
              </label>
              <button
                disabled={busy}
                className="w-full rounded-xl bg-[#DDB13B] p-3 font-bold disabled:opacity-50"
              >
                {busy ? tr("Saving\u2026") : tr("Save password")}
              </button>
            </>
          )
        )}
        <Link
          className="block text-center font-bold text-[#103B35]"
          to="/login"
        >
          {" "}
          {tr("Back to sign in")}{" "}
        </Link>
      </form>
    </main>
  );
}
