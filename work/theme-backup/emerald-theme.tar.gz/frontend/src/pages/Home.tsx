import { useLanguage as useUiLanguage } from "../contexts/LanguageContext";
import { tr } from "../i18n/runtime";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
export default function Home() {
  useUiLanguage();
  const navigate = useNavigate();
  const { language } = useLanguage();
  return (
    <div className="mx-auto max-w-5xl p-4 sm:p-8">
      <div className="relative overflow-hidden rounded-3xl border border-[#103B35]/10 bg-gradient-to-br from-[#103B35] to-[#1B5148] p-8 text-white shadow-xl sm:p-10">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -end-12 -bottom-20 h-56 w-56 rounded-full bg-[#DDB13B]/15 blur-3xl"
        />
        <div className="relative">
          <h1 className="mb-4 text-3xl font-bold text-[#F6E8B7]">
            {language === "ar"
              ? tr("Welcome to WAMEED")
              : tr("Welcome to WAMEED")}
          </h1>
          <p className="mb-6 text-lg text-white/75">
            {language === "ar"
              ? tr(
                  "Everything Under Control. Manage your properties and meters with confidence.",
                )
              : "Everything is under control for efficient property and meter management."}
          </p>
          <button
            onClick={() => navigate("/dashboard")}
            className="rounded-xl bg-[#DDB13B] px-6 py-3 font-bold text-[#103B35] shadow-lg transition-all duration-300 hover:bg-[#E8C65D] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#DDB13B]"
          >
            {language === "ar" ? tr("Go to dashboard") : "Go to Dashboard"}
          </button>
        </div>
      </div>
    </div>
  );
}
