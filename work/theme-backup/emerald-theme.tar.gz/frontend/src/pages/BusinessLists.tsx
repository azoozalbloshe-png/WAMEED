import { useLanguage as useUiLanguage } from "../contexts/LanguageContext";
import { tr, direction } from "../i18n/runtime";
import { FormEvent, useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { Plus } from "lucide-react";
import { realEstateService } from "../services/realEstateService";
import { platform } from "../services/platform";
import { usePermissions } from "../contexts/PermissionsContext";
import {
  Empty,
  Loading,
  Modal,
  Notice,
  PageHead,
  errorText,
  money,
  day,
  useData,
} from "../components/platform/UI";
const labelLink = "font-bold text-emerald-700 underline underline-offset-4";
const states: Record<string, string> = {
  get active() {
    return tr("Active");
  },
  get upcoming() {
    return tr("Upcoming");
  },
  get inactive() {
    return tr("Inactive");
  },
  get cancelled() {
    return tr("Cancelled");
  },
  get expired() {
    return tr("Expired");
  },
};
function List({ kind }: { kind: "tenants" | "contracts" }) {
  useUiLanguage();
  const [params] = useSearchParams();
  const { can, loading: permissionsLoading } = usePermissions();
  const { data, error, loading, refresh } = useData(async () => {
    const [properties, tenants, contracts] = await Promise.all([
      can("properties") ? realEstateService.getProperties() : [],
      can("tenants") ? realEstateService.getTenants() : [],
      can("contracts") ? realEstateService.getContracts() : [],
    ]);
    return { properties, tenants, contracts };
  }, [permissionsLoading]);
  const [query, setQuery] = useState(params.get("q") || ""),
    [property, setProperty] = useState(params.get("property_id") || ""),
    [status, setStatus] = useState(""),
    [open, setOpen] = useState(false),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(""),
    [failure, setFailure] = useState(""),
    [units, setUnits] = useState<any[]>([]);
  const tenantBlank = {
    name: "",
    phone: "",
    email: "",
    national_id: "",
    property_id: "",
    contract_start_date: "",
    contract_end_date: "",
    monthly_rent: "",
    deposit_amount: "0",
  };
  const contractBlank = {
    property_id: "",
    tenant_id: "",
    unit_id: "",
    start_date: "",
    end_date: "",
    monthly_rent: "",
    deposit_amount: "0",
    notes: "",
  };
  const [form, setForm] = useState<Record<string, string>>(
    kind === "tenants" ? tenantBlank : contractBlank,
  );
  useEffect(() => {
    if (kind === "contracts" && form.property_id)
      platform
        .property(form.property_id)
        .then((p) => setUnits(p.units))
        .catch(() => setUnits([]));
    else setUnits([]);
  }, [form.property_id, kind]);
  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setFailure("");
    try {
      const body: any = {
        ...form,
        property_id: Number(form.property_id),
        monthly_rent: Number(form.monthly_rent),
        deposit_amount: Number(form.deposit_amount),
      };
      if (kind === "tenants") {
        body.email = form.email || null;
        for (const k of ["contract_start_date", "contract_end_date"])
          body[k] = new Date(form[k]).toISOString();
        await realEstateService.createTenant(body);
      } else {
        body.tenant_id = Number(form.tenant_id);
        body.unit_id = form.unit_id ? Number(form.unit_id) : null;
        for (const k of ["start_date", "end_date"])
          body[k] = new Date(form[k]).toISOString();
        await realEstateService.createContract(body);
      }
      setMessage(
        kind === "tenants" ? tr("Tenant saved") : tr("Contract saved"),
      );
      setOpen(false);
      setForm(kind === "tenants" ? tenantBlank : contractBlank);
      refresh();
    } catch (e) {
      setFailure(errorText(e));
    } finally {
      setBusy(false);
    }
  }
  const list = (kind === "tenants" ? data?.tenants : data?.contracts) || [];
  const filtered = list.filter((r: any) => {
    const actualStatus =
      kind === "contracts" &&
      r.status === "active" &&
      r.end_date.slice(0, 10) <
        new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Riyadh" })
        ? "expired"
        : r.status;
    return (
      (!property || String(r.property_id) === property) &&
      (!status || actualStatus === status) &&
      `${r.name || ""} ${r.phone || ""} ${r.id} ${r.tenant_name || ""} ${r.property_name || ""}`
        .toLowerCase()
        .includes(query.toLowerCase())
    );
  });
  const fields =
    kind === "tenants"
      ? [
          ["name", tr("Tenant name"), "text"],
          ["phone", tr("Phone"), "tel"],
          ["email", tr("Email address"), "email"],
          ["national_id", tr("ID number"), "text"],
          ["contract_start_date", tr("Rental start"), "date"],
          ["contract_end_date", tr("Rental end"), "date"],
          ["monthly_rent", tr("Monthly rent"), "number"],
          ["deposit_amount", tr("Security deposit"), "number"],
        ]
      : [
          ["start_date", tr("Contract start"), "date"],
          ["end_date", tr("Contract end"), "date"],
          ["monthly_rent", tr("Monthly rent"), "number"],
          ["deposit_amount", tr("Security deposit"), "number"],
          ["notes", tr("Notes"), "text"],
        ];
  return (
    <section className="mx-auto max-w-7xl space-y-5" dir={direction()}>
      <PageHead
        title={kind === "tenants" ? tr("Tenants") : tr("Contracts")}
        description={
          kind === "tenants"
            ? tr("Registered tenants, their profiles and linked contracts.")
            : tr("Your registered contracts, dates, installments and renewals.")
        }
      >
        {can(kind, "create") && (
          <button
            className="btn btn-primary"
            onClick={() => {
              setFailure("");
              setOpen(true);
            }}
          >
            <Plus size={17} />
            {kind === "tenants" ? tr("Add tenant") : tr("Add contract")}
          </button>
        )}
      </PageHead>
      <Notice message={message} />
      <Notice message={error || failure} error />
      <div className="panel grid gap-3 p-4 sm:grid-cols-3">
        <label className="text-xs font-bold">
          {" "}
          {tr("Search")}{" "}
          <input
            className="field"
            aria-label={
              kind === "tenants" ? tr("Search tenants") : tr("Search contracts")
            }
            placeholder={tr("Name or number\u2026")}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <label className="text-xs font-bold">
          {" "}
          {tr("Property")}{" "}
          <select
            className="field"
            value={property}
            onChange={(e) => setProperty(e.target.value)}
          >
            <option value="">{tr("All properties")}</option>
            {data?.properties.map((p) => (
              <option value={p.id} key={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs font-bold">
          {" "}
          {tr("Status")}{" "}
          <select
            className="field"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">{tr("All statuses")}</option>
            {Object.entries(states).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </label>
      </div>
      {loading || permissionsLoading ? (
        <Loading />
      ) : !can(kind) ? (
        <Notice
          message={tr("You do not have permission to view this section.")}
          error
        />
      ) : filtered.length === 0 ? (
        <Empty>
          {" "}
          {tr(
            "No matching records. Adjust your filters or add a record if your role allows it.",
          )}{" "}
        </Empty>
      ) : (
        <div className="panel overflow-x-auto p-3">
          <table className="w-full text-start text-sm">
            <thead>
              <tr>
                {(kind === "tenants"
                  ? [
                      tr("Name"),
                      tr("Phone"),
                      tr("Property"),
                      tr("Monthly rent"),
                      tr("Period"),
                      tr("Details"),
                    ]
                  : [
                      tr("Contract"),
                      tr("Tenant"),
                      tr("Property"),
                      tr("Monthly rent"),
                      tr("Period"),
                      tr("Status"),
                      tr("Unit"),
                    ]
                ).map((h) => (
                  <th className="p-3" key={h}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((r: any) => (
                <tr className="border-t" key={r.id}>
                  {kind === "tenants" ? (
                    <>
                      <td className="p-3 font-bold">
                        <Link to={`/tenants/${r.id}`} className={labelLink}>
                          {r.name}
                        </Link>
                      </td>
                      <td className="p-3" dir="ltr">
                        {r.phone || "—"}
                      </td>
                      <td className="p-3">
                        <Link
                          to={`/properties/${r.property_id}`}
                          className={labelLink}
                        >
                          {r.property?.name ||
                            data?.properties.find((p) => p.id === r.property_id)
                              ?.name ||
                            tr("View property")}
                        </Link>
                      </td>
                      <td className="p-3">{money(r.monthly_rent)}</td>
                      <td className="p-3">
                        {day(r.contract_start_date)} —{" "}
                        {day(r.contract_end_date)}
                      </td>
                      <td className="p-3">
                        <Link className="btn" to={`/tenants/${r.id}`}>
                          {" "}
                          {tr("Tenant profile")}{" "}
                        </Link>
                      </td>
                    </>
                  ) : (
                    <>
                      <td className="p-3">
                        <Link to={`/contracts/${r.id}`} className={labelLink}>
                          #{r.id}
                        </Link>
                      </td>
                      <td className="p-3">
                        <Link
                          className={labelLink}
                          to={`/tenants/${r.tenant_id}`}
                        >
                          {r.tenant_name}
                        </Link>
                      </td>
                      <td className="p-3">
                        <Link
                          className={labelLink}
                          to={`/properties/${r.property_id}`}
                        >
                          {r.property_name}
                        </Link>
                      </td>
                      <td className="p-3">{money(r.monthly_rent)}</td>
                      <td className="p-3">
                        {day(r.start_date)} — {day(r.end_date)}
                      </td>
                      <td className="p-3">{states[r.status]}</td>
                      <td className="p-3">
                        {r.unit_id ? (
                          <Link
                            className={labelLink}
                            to={`/units/${r.unit_id}`}
                          >
                            {" "}
                            {tr("View unit")}{" "}
                          </Link>
                        ) : (
                          <Link className={labelLink} to={`/contracts/${r.id}`}>
                            {" "}
                            {tr("Link a unit")}{" "}
                          </Link>
                        )}
                      </td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {open && (
        <Modal
          title={kind === "tenants" ? tr("Add tenant") : tr("Create contract")}
          onClose={() => setOpen(false)}
        >
          <form className="grid gap-4 sm:grid-cols-2" onSubmit={save}>
            <label className="text-sm">
              {" "}
              {tr("Property")}{" "}
              <select
                className="field"
                required
                value={form.property_id}
                onChange={(e) =>
                  setForm({
                    ...form,
                    property_id: e.target.value,
                    tenant_id: "",
                    unit_id: "",
                  })
                }
              >
                <option value="">{tr("Select property")}</option>
                {data?.properties.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
            {kind === "contracts" && (
              <>
                <label className="text-sm">
                  {" "}
                  {tr("Tenant")}{" "}
                  <select
                    className="field"
                    required
                    value={form.tenant_id}
                    onChange={(e) =>
                      setForm({ ...form, tenant_id: e.target.value })
                    }
                  >
                    <option value="">{tr("Select tenant")}</option>
                    {data?.tenants
                      .filter((t) => String(t.property_id) === form.property_id)
                      .map((t) => (
                        <option value={t.id} key={t.id}>
                          {t.name}
                        </option>
                      ))}
                  </select>
                </label>
                <label className="text-sm">
                  {" "}
                  {tr("Unit")}{" "}
                  <select
                    className="field"
                    value={form.unit_id}
                    onChange={(e) =>
                      setForm({ ...form, unit_id: e.target.value })
                    }
                  >
                    <option value="">{tr("Link later")}</option>
                    {units.map((u) => (
                      <option value={u.id} key={u.id}>
                        {u.number} ·{" "}
                        {u.status === "occupied"
                          ? tr("Occupied")
                          : u.status === "maintenance"
                            ? tr("Maintenance")
                            : tr("Available")}
                      </option>
                    ))}
                  </select>
                </label>
              </>
            )}
            {fields.map(([key, label, type]) => (
              <label className="text-sm" key={key}>
                {label}
                <input
                  className="field"
                  required={[
                    "name",
                    "start_date",
                    "end_date",
                    "contract_start_date",
                    "contract_end_date",
                    "monthly_rent",
                  ].includes(key)}
                  type={type}
                  lang={
                    ["number", "date", "datetime-local", "tel"].includes(type)
                      ? "en"
                      : undefined
                  }
                  min={type === "number" ? 0 : undefined}
                  step={type === "number" ? "0.01" : undefined}
                  value={form[key] || ""}
                  onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                />
              </label>
            ))}
            <div className="space-y-3 sm:col-span-2">
              <Notice message={failure} error />
              <button disabled={busy} className="btn btn-primary">
                {busy ? tr("Saving\u2026") : tr("Save record")}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </section>
  );
}
export function TenantsPage() {
  useUiLanguage();
  return <List kind="tenants" />;
}
export function ContractsPage() {
  useUiLanguage();
  return <List kind="contracts" />;
}
