import { numberLocale } from "../i18n/runtime";
import { useLanguage as useUiLanguage } from "../contexts/LanguageContext";
import { tr, direction } from "../i18n/runtime";
import { Link } from "react-router-dom";
import { usePermissions } from "../contexts/PermissionsContext";
import { Loading, PageHead } from "../components/platform/UI";
import { FormEvent, useEffect, useState } from "react";
import { Building2, Plus, Search, MapPin } from "lucide-react";
import {
  PropertyRecord,
  realEstateService,
} from "../services/realEstateService";
const initial = {
  name: "",
  description: "",
  property_type: "apartment",
  address: "",
  city: "",
  total_units: "0",
  monthly_rent: "0",
};
export default function Properties() {
  useUiLanguage();
  const { can } = usePermissions();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<PropertyRecord[]>([]);
  const [form, setForm] = useState(initial);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const load = () =>
    realEstateService
      .getProperties()
      .then(setItems)
      .catch((e) =>
        setError(e?.response?.data?.detail || tr("Unable to load properties.")),
      )
      .finally(() => setLoading(false));
  useEffect(() => {
    void load();
  }, []);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await realEstateService.createProperty({
        ...form,
        total_units: Number(form.total_units),
        monthly_rent: Number(form.monthly_rent),
      });
      setForm(initial);
      setOpen(false);
      await load();
    } catch (e: any) {
      setError(e?.response?.data?.detail || tr("Unable to save the property."));
    } finally {
      setBusy(false);
    }
  }
  const visible = items.filter((p) =>
    `${p.name} ${p.city || ""} ${p.address || ""}`
      .toLowerCase()
      .includes(query.toLowerCase()),
  );
  return (
    <div className="mx-auto max-w-7xl space-y-6" dir={direction()}>
      <PageHead
        title={tr("Properties")}
        description={tr("Your saved property records.")}
      >
        {can("properties", "create") && (
          <button
            onClick={() => setOpen(!open)}
            className="flex items-center gap-2 rounded-xl bg-[#DDB13B] px-4 py-3 font-bold text-[#25313A]"
          >
            <Plus size={18} />
            {tr("Add property")}{" "}
          </button>
        )}
      </PageHead>
      {error && (
        <p
          role="alert"
          className="rounded-xl bg-red-50 p-3 text-sm text-red-700"
        >
          {tr(error)}
        </p>
      )}
      {open && (
        <form
          onSubmit={submit}
          className="grid gap-3 rounded-2xl border bg-white p-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {[
            ["name", tr("Property name")],
            ["city", tr("City")],
            ["address", tr("Address")],
            ["total_units", tr("Number of units")],
            ["monthly_rent", tr("Monthly rent")],
            ["description", tr("Description")],
          ].map(([key, label]) => (
            <label key={key} className="text-sm font-bold">
              {label}
              <input
                required={key === "name"}
                type={
                  key === "total_units" || key === "monthly_rent"
                    ? "number"
                    : "text"
                }
                min={
                  key === "total_units" || key === "monthly_rent"
                    ? 0
                    : undefined
                }
                value={(form as any)[key]}
                onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                className="mt-1 w-full rounded-xl border p-3 font-normal"
              />
            </label>
          ))}
          <label className="text-sm font-bold">
            {" "}
            {tr("Property type")}{" "}
            <select
              value={form.property_type}
              onChange={(e) =>
                setForm({ ...form, property_type: e.target.value })
              }
              className="mt-1 w-full rounded-xl border p-3"
            >
              <option value="apartment">{tr("Apartments")}</option>
              <option value="villa">{tr("Villa")}</option>
              <option value="townhouse">{tr("Townhouse")}</option>
              <option value="commercial">{tr("Commercial")}</option>
            </select>
          </label>
          <div className="flex items-end">
            <button
              disabled={busy}
              className="rounded-xl bg-[#103B35] px-5 py-3 font-bold text-white"
            >
              {busy ? tr("Saving\u2026") : tr("Save property")}
            </button>
          </div>
        </form>
      )}
      <label className="relative block">
        <Search className="absolute start-3 top-3 h-5 w-5 text-gray-400" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={tr("Search by name or location")}
          className="w-full rounded-xl border bg-white py-3 ps-11 pe-4"
        />
      </label>
      {loading ? (
        <Loading />
      ) : items.length === 0 && !error ? (
        <div className="rounded-2xl border border-dashed bg-white p-10 text-center text-gray-500">
          <Building2 className="mx-auto mb-3" />
          {tr("No properties registered yet.")}{" "}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {visible.map((p) => (
            <article
              key={p.id}
              className="rounded-2xl border bg-white p-5 shadow-sm"
            >
              <div className="flex items-center gap-3">
                <Building2 className="text-[#15966D]" />
                <h2 className="font-black">
                  <Link
                    className="underline underline-offset-4"
                    to={`/properties/${p.id}`}
                  >
                    {p.name}
                  </Link>
                </h2>
              </div>
              <p className="mt-3 flex items-center gap-1 text-sm text-gray-500">
                <MapPin size={15} />
                {[p.city, p.address].filter(Boolean).join(" · ") ||
                  tr("Location not specified")}
              </p>
              <p className="mt-4 text-sm">
                {" "}
                {tr("Units:")}
                <b>{p.total_units}</b>
                {tr("\u00B7 Recorded rent:")}{" "}
                <b>
                  {Number(p.monthly_rent || 0).toLocaleString(numberLocale())}{" "}
                  {tr("SAR")}{" "}
                </b>
              </p>
              <p className="mt-2 text-xs text-gray-500">
                {" "}
                {tr(
                  "Occupancy and details are linked to tenant and contract records.",
                )}{" "}
              </p>
              <Link className="btn mt-4 w-full" to={`/properties/${p.id}`}>
                {" "}
                {tr("View property & units")}{" "}
              </Link>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
